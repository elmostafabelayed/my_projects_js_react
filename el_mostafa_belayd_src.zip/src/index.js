import React from "react";
import ReactDOM from "react-dom/client";
 import App from "./TP4/Ex6/App";

import "bootstrap/dist/css/bootstrap.min.css"


const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App/>)